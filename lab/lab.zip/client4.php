<!---------------------------------------------------------------------------
Example client script for JQUERY:AJAX -> PHP:MYSQL example
---------------------------------------------------------------------------->

<html>
  <head>
 <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> 
 
 <script src="js/jquery_ajaz.js"></script>
  </head>
  <body>

 
  
  <table border="1" id="msg"><tr><th>Lease Owner</th><th>Request Poster</th><th>email</th><th>address</th><th>start date</th><th>end date</th><th>expected rent</th><th>deposit</th><th>notes</th></tr></table>

<script type="text/javascript">

 
</script>


  </body>
</html>
